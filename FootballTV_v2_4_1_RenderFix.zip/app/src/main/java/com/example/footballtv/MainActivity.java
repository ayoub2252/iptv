package com.example.footballtv;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import android.text.InputType;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import okhttp3.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;

@UnstableApi
public class MainActivity extends AppCompatActivity {
    private static final int PICK_M3U = 41, EXPORT_M3U = 42;
    private final int BG=Color.rgb(11,18,32), PANEL=Color.rgb(25,38,57), GREEN=Color.rgb(22,168,117);
    private LinearLayout root, content, rows;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(12, TimeUnit.SECONDS)
            .callTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    // Separate bounded pools prevent slow images/API calls from blocking playlist actions.
    private final ExecutorService worker=Executors.newFixedThreadPool(4);
    private final ExecutorService imageWorker=Executors.newFixedThreadPool(3);
    private final android.util.LruCache<String, android.graphics.Bitmap> logoCache =
            new android.util.LruCache<String, android.graphics.Bitmap>(4 * 1024 * 1024) {
                @Override protected int sizeOf(String key, android.graphics.Bitmap value) {
                    return value.getByteCount();
                }
            };
    private final ArrayList<Stream> streams=new ArrayList<>();
    // VOD catalogs are kept separately from live channels; Xtream credentials stay in memory only.
    private final ArrayList<Stream> movies=new ArrayList<>();
    private final ArrayList<Stream> series=new ArrayList<>();
    private String xtreamServer="", xtreamUser="", xtreamPass="";
    private String catalogSource="";
    private String currentMediaUrl="";
    private final HashSet<String> favorites=new HashSet<>();
    private final LinkedHashSet<String> recentUrls=new LinkedHashSet<>();
    private SharedPreferences prefs;
    private ExoPlayer player;
    private PlayerView playerView;
    private EditText serverInput,userInput,passInput,searchInput;
    private String activePlaylistName="فهرست من";
    private String nextPlaylistName="";
    private EditText profileNameInput;
    private boolean loading=false;
    private volatile boolean savedPlaylistLoaded=false;
    private String currentScreenTitle="";
    private String sportsApiKey="";
    private String sportmonksApiKey="";
    private String soccersApiKey="";
    private final ArrayList<JSONObject> lastFixtures=new ArrayList<>();
    private final LinkedHashMap<String,JSONObject> sportsLeagues=new LinkedHashMap<>();
    private String selectedSportsLeague="همه رقابت‌ها";

    static class Stream {
        String name,url,group,logo,id,extension,plot,year;
        Stream(String n,String u,String g,String l){name=n;url=u;group=g;logo=l;id="";extension="";plot="";year="";}
        Stream(String n,String u,String g,String l,String itemId,String ext,String description,String releaseYear){this(n,u,g,l);id=itemId;extension=ext;plot=description;year=releaseYear;}
        JSONObject json(){JSONObject o=new JSONObject();try{o.put("name",name);o.put("url",url);o.put("group",group);o.put("logo",logo);}catch(Exception ignored){}return o;}
        static Stream from(JSONObject o){return new Stream(o.optString("name"),o.optString("url"),o.optString("group","سایر"),o.optString("logo",""));}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("football_tv",MODE_PRIVATE);
        sportmonksApiKey=prefs.getString("sportmonks_api_key", "");
        sportsApiKey=prefs.getString("api_football_key", "");
        soccersApiKey=prefs.getString("soccers_api_key", "");
        loadSaved();
        favorites.addAll(prefs.getStringSet("favorites",new HashSet<>()));
        recentUrls.addAll(prefs.getStringSet("recent",new LinkedHashSet<>()));
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        home();
    }
    private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setPadding(12,10,12,10);return t;}
    private Button action(String s,Runnable r){
        Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);
        b.setTextSize(15);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PANEL));
        b.setOnClickListener(v->r.run());b.setFocusable(true);b.setFocusableInTouchMode(true);
        return b;
    }
    private EditText field(String hint,int type){
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xff9EADC0);e.setInputType(type);e.setPadding(16,8,16,8);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));return e;
    }
    private void base(String title){
        currentScreenTitle=title;
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(12,8,12,8);root.setBackgroundColor(BG);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(4,4,4,8);
        TextView brand=label("⚽  FOOTBALL TV",18);brand.setTypeface(null,1);brand.setTextColor(GREEN);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView page=label(title,13);page.setTextColor(0xffB8C7D9);top.addView(page);root.addView(top);
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);content.setPadding(2,2,2,16);content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.setFillViewport(true);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(0);nav.setGravity(Gravity.CENTER);nav.setPadding(2,6,2,2);nav.setBackgroundColor(0xff101B2B);
        nav.addView(navItem("⌂\nخانه",()->home()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navItem("⚽\nمسابقات",()->sportsCenter()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navItem("▣\nشبکه‌ها",()->channels(false)),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navItem("🎬\nفیلم‌ها",()->moviesPage()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navItem("▤\nسریال‌ها",()->seriesPage()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navItem("＋\nافزودن",()->playlistLoginScreen()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navItem("⚙\nتنظیمات",()->playlistTools()),new LinearLayout.LayoutParams(0,-2,1));
        root.addView(nav);setContentView(root);
        TextView heading=label(title,22);heading.setTextColor(Color.WHITE);heading.setTypeface(null,1);content.addView(heading);
    }
    private TextView navItem(String text,Runnable click){TextView t=label(text,11);t.setGravity(Gravity.CENTER);t.setTextColor(0xffDCE6F2);t.setPadding(2,5,2,5);t.setOnClickListener(v->click.run());return t;}
    private LinearLayout panel(){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(12,12,12,12);box.setBackgroundColor(PANEL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,8);box.setLayoutParams(lp);return box;}
    private void section(String title){TextView t=label(title,17);t.setTypeface(null,1);t.setTextColor(0xffEAF2FA);content.addView(t);}
    private void home(){
        base("خانه");
        LinearLayout hero=panel();hero.setBackgroundColor(0xff142B43);
        TextView eyebrow=label("FOOTBALL • LIVE • IPTV",11);eyebrow.setTextColor(0xff70D8B1);hero.addView(eyebrow);
        TextView headline=label("فوتبال را زنده دنبال کن",23);headline.setTypeface(null,1);hero.addView(headline);
        hero.addView(label("مسابقات، نتایج و شبکه‌های ورزشی در یک‌جا",13));
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(0);
        stats.addView(statBox(String.valueOf(streams.size()),"کانال"),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(statBox(String.valueOf(favorites.size()),"علاقه‌مندی"),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(statBox(String.valueOf(recentUrls.size()),"اخیر"),new LinearLayout.LayoutParams(0,-2,1));hero.addView(stats);
        hero.addView(action(streams.isEmpty()?"＋  افزودن فهرست پخش":"▶  ورود به شبکه‌های زنده",()->{if(streams.isEmpty())playlistLoginScreen();else channels(false);}));content.addView(hero);
        section("دسترسی سریع");
        LinearLayout quick=new LinearLayout(this);quick.setOrientation(0);
        quick.addView(quickTile("⚽","مسابقات زنده",()->sportsCenter()),new LinearLayout.LayoutParams(0,-2,1));
        quick.addView(quickTile("▣","همه شبکه‌ها",()->channels(false)),new LinearLayout.LayoutParams(0,-2,1));
        quick.addView(quickTile("★","علاقه‌مندی‌ها",()->channels(true)),new LinearLayout.LayoutParams(0,-2,1));content.addView(quick);
        LinearLayout vodQuick=new LinearLayout(this);vodQuick.setOrientation(0);
        vodQuick.addView(quickTile("🎬","فیلم‌ها",()->moviesPage()),new LinearLayout.LayoutParams(0,-2,1));
        vodQuick.addView(quickTile("▤","سریال‌ها",()->seriesPage()),new LinearLayout.LayoutParams(0,-2,1));content.addView(vodQuick);
        section("سرگرمی و ویدئو");
        LinearLayout mediaQuick=new LinearLayout(this);mediaQuick.setOrientation(0);
        mediaQuick.addView(quickTile("🎬","فیلم‌ها ("+movies.size()+")",()->moviesPage()),new LinearLayout.LayoutParams(0,-2,1));
        mediaQuick.addView(quickTile("▤","سریال‌ها ("+series.size()+")",()->seriesPage()),new LinearLayout.LayoutParams(0,-2,1));content.addView(mediaQuick);
        section("فهرست پخش من");LinearLayout playlist=panel();
        playlist.addView(label(streams.isEmpty()?"هنوز فهرست پخشی اضافه نکرده‌اید":"فهرست فعال: "+activePlaylistName,15));
        playlist.addView(label(streams.isEmpty()?"با لینک M3U یا مشخصات Xtream Codes متصل شوید.":streams.size()+" شبکه آماده دسترسی است.",12));
        playlist.addView(action("＋  افزودن یا مدیریت فهرست پخش",()->playlistLoginScreen()));
        if(!streams.isEmpty()){playlist.addView(action("↻  به‌روزرسانی فهرست",()->refreshPlaylist()));playlist.addView(action("◷  آخرین پخش‌ها",()->recentPage()));}
        content.addView(playlist);
        section("لیگ‌های محبوب");
        String[][] leagues={{"🇬🇧","لیگ انگلیس"},{"🇪🇸","لالیگا اسپانیا"},{"🇮🇹","سری آ ایتالیا"},{"🇩🇪","بوندس‌لیگا آلمان"},{"🇫🇷","لیگ فرانسه"},{"🇸🇦","لیگ عربستان"},{"🇮🇷","لیگ ایران"},{"🏆","لیگ قهرمانان اروپا"},{"🏆","لیگ اروپا (یوفا)"}};
        for(String[] l:leagues)content.addView(action(l[0]+"   "+l[1]+"     ›",()->leaguePage(l[1])));
        section("ابزارها");content.addView(action("📊  جدول رده‌بندی لیگ‌ها",()->standingsScreen()));content.addView(action("⚙  تنظیمات و مدیریت فهرست",()->playlistTools()));content.addView(action("راهنما",()->help()));
    }
    private LinearLayout statBox(String value,String caption){LinearLayout b=new LinearLayout(this);b.setOrientation(1);b.setPadding(8,6,8,6);TextView v=label(value,19);v.setTypeface(null,1);v.setTextColor(GREEN);b.addView(v);b.addView(label(caption,11));return b;}
    private TextView quickTile(String icon,String title,Runnable run){TextView t=label(icon+"\n"+title,13);t.setGravity(Gravity.CENTER);t.setBackgroundColor(PANEL);t.setPadding(6,14,6,14);t.setOnClickListener(v->run.run());return t;}
    private void playlistLoginScreen(){
        base("افزودن فهرست پخش");
        content.addView(label("برای شروع، روش اتصال را انتخاب کنید.",14));
        LinearLayout xt=panel();xt.addView(label("▣  ورود با Xtream Codes API",18));xt.addView(label("آدرس سرور + نام کاربری + رمز عبور",12));xt.addView(action("ورود با Xtream Codes",()->xtreamScreen()));content.addView(xt);
        LinearLayout m3=panel();m3.addView(label("🔗  بارگذاری با لینک M3U / M3U8",18));m3.addView(label("لینک مستقیم فهرست پخش ارائه‌دهنده",12));m3.addView(action("وارد کردن لینک M3U",()->m3uScreen()));content.addView(m3);
        LinearLayout file=panel();file.addView(label("📁  انتخاب فایل از گوشی",18));file.addView(label("فایل محلی با فرمت M3U یا M3U8",12));file.addView(action("انتخاب فایل",()->pickM3u()));content.addView(file);
        content.addView(label("اطلاعات ورود Xtream در حافظه دائمی ذخیره نمی‌شود. فقط از اشتراک‌های مجاز خود استفاده کنید.",12));
    }
    private void sportsCenter(){
        base("مرکز مسابقات فوتبال");
        content.addView(label("برنامه هفت روز آینده • ساعت رسمی ایران • تاریخ شمسی",16));
        content.addView(label("رقابت‌های تحت پوشش: لیگ‌های برتر انگلیس، اسپانیا، ایتالیا، آلمان و فرانسه؛ لیگ قهرمانان اروپا، لیگ اروپا، لیگ برتر ایران، لیگ قهرمانان آسیا Elite و لیگ حرفه‌ای عربستان",13));
        EditText key=field("کلید API-Football (API key)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(sportsApiKey);content.addView(key);
        content.addView(label("کلید API-Football برای مسابقات و کلید SoccersAPI برای شبکه‌های پخش مسابقه استفاده می‌شود. در حساب رایگان SoccersAPI فقط سه لیگ انتخابی حساب شما قابل دسترسی است.",12));
        EditText scKey=field("کلید رایگان SoccersAPI (شبکه‌های پخش)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        scKey.setText(soccersApiKey);content.addView(scKey);
        content.addView(action("ذخیره کلید SoccersAPI",()->{soccersApiKey=scKey.getText().toString().trim();prefs.edit().putString("soccers_api_key",soccersApiKey).apply();toast(soccersApiKey.isEmpty()?"کلید SoccersAPI پاک شد.":"کلید SoccersAPI ذخیره شد.");}));
        content.addView(label("توجه: طرح رایگان API-Football روزانه ۱۰۰ درخواست دارد. SoccersAPI رایگان نیز فقط سه لیگ انتخابی شما را پوشش می‌دهد؛ هیچ‌کدام گزارشگر عربی را تضمین نمی‌کنند.",12));
        content.addView(action("دریافت برنامه کامل ۷ روز آینده",()->{
            String k=key.getText().toString().trim();
            if(k.isEmpty()){toast("ابتدا کلید API را وارد کنید.");return;}
            sportsApiKey=k;prefs.edit().putString("api_football_key",k).apply();
            String sc=scKey.getText().toString().trim();if(!sc.isEmpty()){soccersApiKey=sc;prefs.edit().putString("soccers_api_key",sc).apply();}
            loadSportsWeek();
        }));
        content.addView(label("زمان‌بندی به وقت Asia/Tehran نمایش داده می‌شود. اگر مسابقه‌ای زمان قطعی نداشته باشد، «ساعت اعلام نشده» نمایش داده خواهد شد.",12));
        content.addView(action("راهنمای دریافت اطلاعات ورزشی",()->new AlertDialog.Builder(this).setTitle("اطلاعات مسابقات").setMessage("این بخش از API-Football استفاده می‌کند. در حساب سرویس، پوشش هر لیگ و فصل را بررسی کنید؛ ممکن است بعضی لیگ‌ها در طرح انتخابی شما در دسترس نباشند. برنامه زمان یا نتیجه ساختگی نشان نمی‌دهد.").setPositiveButton("متوجه شدم",null).show()));
    }
    private void loadSportsWeek(){
        if(sportsApiKey.isEmpty()){toast("کلید API وارد نشده است.");return;}
        base("مسابقات هفت روز آینده");
        content.addView(label("در حال دریافت برنامه رسمی رقابت‌ها…",15));
        worker.execute(()->{
            ArrayList<JSONObject> found=new ArrayList<>();LinkedHashMap<String,JSONObject> leagues=new LinkedHashMap<>();
            String[] searches={"Persian Gulf Pro League","AFC Champions League Elite","Saudi Pro League",
                    "Premier League","La Liga","Serie A","Bundesliga","Ligue 1","UEFA Champions League","UEFA Europa League"};
            String[] labels={"لیگ برتر ایران","لیگ قهرمانان آسیا Elite","لیگ حرفه‌ای عربستان",
                    "لیگ برتر انگلیس","لالیگا اسپانیا","سری آ ایتالیا","بوندس‌لیگا آلمان","لیگ فرانسه",
                    "لیگ قهرمانان اروپا","لیگ اروپا (یوفا)"};
            try{
                Calendar cal=Calendar.getInstance(TimeZone.getTimeZone("Asia/Tehran"));
                SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);df.setTimeZone(TimeZone.getTimeZone("Asia/Tehran"));
                String from=df.format(cal.getTime());cal.add(Calendar.DAY_OF_YEAR,6);String to=df.format(cal.getTime());
                int season=Calendar.getInstance(TimeZone.getTimeZone("Asia/Tehran")).get(Calendar.YEAR);
                for(int x=0;x<searches.length;x++){
                    JSONObject leagueResp=new JSONObject(apiGet("https://v3.football.api-sports.io/leagues?search="+enc(searches[x])+"&season="+season));
                    JSONArray leagueArr=leagueResp.optJSONArray("response");if(leagueArr==null)continue;
                    JSONObject chosen=null;
                    for(int i=0;i<leagueArr.length();i++){
                        JSONObject entry=leagueArr.optJSONObject(i);JSONObject lg=entry==null?null:entry.optJSONObject("league");
                        if(lg==null)continue;
                        String nm=lg.optString("name").toLowerCase(Locale.ROOT);
                        String country=entry.optJSONObject("country")==null?"":entry.optJSONObject("country").optString("name").toLowerCase(Locale.ROOT);
                        boolean match=false;
                        switch(x){
                            case 0: match=nm.contains("persian gulf")||("pro league".equals(nm)&&country.contains("iran")); break;
                            case 1: match=nm.contains("champions league")&&(country.contains("asia")||searches[x].startsWith("AFC")); break;
                            case 2: match=nm.contains("pro league")&&country.contains("saudi"); break;
                            case 3: match=nm.equals("premier league")&&country.contains("england"); break;
                            case 4: match=(nm.equals("la liga")||nm.equals("laliga"))&&(country.contains("spain")||country.isEmpty()); break;
                            case 5: match=nm.equals("serie a")&&country.contains("italy"); break;
                            case 6: match=nm.equals("bundesliga")&&country.contains("germany"); break;
                            case 7: match=nm.equals("ligue 1")&&country.contains("france"); break;
                            case 8: match=nm.equals("uefa champions league")||nm.equals("champions league"); break;
                            case 9: match=nm.equals("uefa europa league")||nm.equals("europa league"); break;
                        }
                        if(match){chosen=entry;break;}
                    }
                    if(chosen==null)continue;
                    JSONObject lg=chosen.getJSONObject("league");String id=lg.optString("id");String key=labels[x]+"|"+id;
                    JSONObject meta=new JSONObject();meta.put("id",id);meta.put("name",labels[x]);meta.put("season",currentSeason(chosen));
                    leagues.put(key,meta);
                    String url="https://v3.football.api-sports.io/fixtures?league="+id+"&season="+meta.optInt("season")+"&from="+from+"&to="+to+"&timezone=Asia%2FTehran";
                    JSONObject fx=new JSONObject(apiGet(url));JSONArray arr=fx.optJSONArray("response");
                    if(arr!=null)for(int j=0;j<arr.length();j++){JSONObject f=arr.optJSONObject(j);if(f!=null){f.put("_league_label",labels[x]);found.add(f);}}
                }
                if(!soccersApiKey.isEmpty()) enrichSoccersBroadcast(found,from,to);
                else if(!sportmonksApiKey.isEmpty()) enrichBroadcastStations(found,from,to);
                Collections.sort(found,(a,b)->a.optJSONObject("fixture").optString("date").compareTo(b.optJSONObject("fixture").optString("date")));
                runOnUiThread(()->renderSportsFixtures(found,leagues,from,to));
            }catch(Exception e){runOnUiThread(()->{base("خطا در دریافت مسابقات");content.addView(label("دریافت اطلاعات انجام نشد: "+e.getMessage(),14));content.addView(action("تلاش دوباره",()->loadSportsWeek()));});}
        });
    }
    private String apiGet(String url)throws Exception{
        Request req=new Request.Builder().url(url).addHeader("x-apisports-key",sportsApiKey).addHeader("Accept","application/json").build();
        try(Response r=http.newCall(req).execute()){if(!r.isSuccessful())throw new Exception("HTTP "+r.code());String body=r.body().string();JSONObject obj=new JSONObject(body);Object errors=obj.opt("errors");if(errors!=null&&!errors.toString().equals("{}")&&!errors.toString().equals("[]"))throw new Exception(errors.toString());return body;}
    }
    private void renderSportsFixtures(ArrayList<JSONObject> fixtures,LinkedHashMap<String,JSONObject> leagues,String from,String to){
        lastFixtures.clear();lastFixtures.addAll(fixtures);sportsLeagues.clear();sportsLeagues.putAll(leagues);
        base("مسابقات هفت روز آینده");
        content.addView(label("از "+persianDate(from)+" تا "+persianDate(to)+" • ساعت ایران",14));
        Spinner filter=new Spinner(this);ArrayList<String> opts=new ArrayList<>();opts.add("همه رقابت‌ها");opts.addAll(Arrays.asList("لیگ برتر ایران","لیگ قهرمانان آسیا Elite","لیگ حرفه‌ای عربستان",
                "لیگ برتر انگلیس","لالیگا اسپانیا","سری آ ایتالیا","بوندس‌لیگا آلمان","لیگ فرانسه",
                "لیگ قهرمانان اروپا","لیگ اروپا (یوفا)"));
        ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,opts);ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);filter.setAdapter(ad);content.addView(filter);
        LinearLayout list=new LinearLayout(this);list.setOrientation(1);content.addView(list);
        Runnable render=()->{list.removeAllViews();String selected=String.valueOf(filter.getSelectedItem());int count=0;String currentDay="";
            for(JSONObject f:lastFixtures){String league=f.optString("_league_label");if(!"همه رقابت‌ها".equals(selected)&&!selected.equals(league))continue;
                JSONObject fix=f.optJSONObject("fixture"),teams=f.optJSONObject("teams"),home=teams==null?null:teams.optJSONObject("home"),away=teams==null?null:teams.optJSONObject("away"),goals=f.optJSONObject("goals"),status=fix==null?null:fix.optJSONObject("status");
                String date=fix==null?"":fix.optString("date");String day=persianDate(date);if(!day.equals(currentDay)){list.addView(label("📅  "+day,18));currentDay=day;}
                String time=iranTime(date);String hn=home==null?"تیم میزبان":home.optString("name");String an=away==null?"تیم میهمان":away.optString("name");String st=status==null?"":status.optString("long");String shortStatus=status==null?"":status.optString("short");
                String score=(goals==null||goals.isNull("home")||goals.isNull("away"))?"— : —":goals.optString("home")+" : "+goals.optString("away");
                String live=(shortStatus.equals("1H")||shortStatus.equals("2H")||shortStatus.equals("HT")||shortStatus.equals("ET")||shortStatus.equals("P"))?"🔴 زنده • "+(fix==null?"":fix.optJSONObject("status").optString("elapsed",""))+"′":st;
                LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(8,8,8,8);card.setBackgroundColor(PANEL);
                card.addView(label("🏆 "+league+"   •   "+time,13));LinearLayout teamsRow=new LinearLayout(this);teamsRow.setOrientation(0);teamsRow.setGravity(Gravity.CENTER_VERTICAL);ImageView hi=new ImageView(this),ai=new ImageView(this);int logoSize=(int)(44*getResources().getDisplayMetrics().density);teamsRow.addView(hi,new LinearLayout.LayoutParams(logoSize,logoSize));TextView match=label(hn+"   "+score+"   "+an,15);teamsRow.addView(match,new LinearLayout.LayoutParams(0,-2,1));teamsRow.addView(ai,new LinearLayout.LayoutParams(logoSize,logoSize));card.addView(teamsRow);if(home!=null)loadTeamLogo(hi,home.optString("logo"));if(away!=null)loadTeamLogo(ai,away.optString("logo"));card.addView(label(live,12));
                String tvInfo=f.optString("_tv_stations", "");
                String tvSource=f.optString("_tv_source", "");
                if(!tvInfo.isEmpty()) card.addView(label("📺 شبکه پخش"+(tvSource.isEmpty()?"":" • "+tvSource)+": "+tvInfo,13));
                else if(!soccersApiKey.isEmpty()) card.addView(label("📺 شبکه پخش: در داده‌های SoccersAPI برای این مسابقه ثبت نشده یا لیگ در طرح رایگان شما نیست.",12));
                else if(!sportmonksApiKey.isEmpty()) card.addView(label("📺 شبکه پخش: اطلاعات قابل تأیید در Sportmonks موجود نیست؛ طرح رایگان پوشش بسیار محدودی دارد.",12));
                else card.addView(label("📺 برای جست‌وجوی خودکار شبکه، کلید SoccersAPI را وارد کنید.",12));
                card.addView(action("🔔  افزودن یادآور به تقویم",()->addMatchReminder(hn,an,date)));
                if(isEuropeanCompetition(league)){
                    card.addView(action("📺  شبکه beIN عربی و گزارشگر این بازی",()->checkBeinArabicMatch(hn,an,league,date)));
                }
                card.addView(action("جست‌وجوی کانال مرتبط در فهرست من",()->findMatchChannels(hn,an,league)));
                list.addView(card);count++;
            }
            if(count==0)list.addView(label("برای این بازه مسابقه‌ای در داده‌های دریافتی پیدا نشد؛ پوشش لیگ و فصل را در سرویس داده بررسی کنید.",14));
        };
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render.run();}public void onNothingSelected(android.widget.AdapterView<?> p){}});
        render.run();content.addView(action("↻  به‌روزرسانی نتایج و وضعیت",()->loadSportsWeek()));
        content.addView(action("📊  جدول رده‌بندی",()->standingsScreen()));
    }
    private String soccersGet(String url)throws Exception{
        Request req=new Request.Builder().url(url).header("Accept","application/json").build();
        try(Response r=http.newCall(req).execute()){
            String body=r.body()==null?"":r.body().string();
            if(!r.isSuccessful())throw new IOException("SoccersAPI HTTP "+r.code()+": "+body);
            return body;
        }
    }
    private boolean teamNameMatches(String a,String b){
        String x=normTeam(a),y=normTeam(b);
        return !x.isEmpty()&&!y.isEmpty()&&(x.equals(y)||x.contains(y)||y.contains(x));
    }
    private void enrichSoccersBroadcast(ArrayList<JSONObject> fixtures,String from,String to){
        try{
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
            Calendar day=Calendar.getInstance(TimeZone.getTimeZone("Asia/Tehran"));day.setTime(df.parse(from));Date end=df.parse(to);
            while(!day.getTime().after(end)){
                String d=df.format(day.getTime());
                String url="https://api.soccersapi.com/v2.2/broadcast/?api_key="+Uri.encode(soccersApiKey)+"&t=schedule&d="+d+"&include=tvs&utc=3.5&lang=en&page=1";
                JSONObject response=new JSONObject(soccersGet(url));JSONArray data=response.optJSONArray("data");
                if(data!=null){
                    for(JSONObject appFixture:fixtures){
                        JSONObject af=appFixture.optJSONObject("fixture"),teams=appFixture.optJSONObject("teams");
                        if(af==null||teams==null)continue;String iso=af.optString("date");if(iso.length()<10||!iso.substring(0,10).equals(d))continue;
                        JSONObject home=teams.optJSONObject("home"),away=teams.optJSONObject("away");if(home==null||away==null)continue;
                        for(int i=0;i<data.length();i++){
                            JSONObject sf=data.optJSONObject(i),st=sf==null?null:sf.optJSONObject("teams");if(st==null)continue;
                            JSONObject sh=st.optJSONObject("home"),sa=st.optJSONObject("away");if(sh==null||sa==null)continue;
                            if(teamNameMatches(home.optString("name"),sh.optString("name"))&&teamNameMatches(away.optString("name"),sa.optString("name"))){
                                JSONArray tvs=sf.optJSONArray("tvs");LinkedHashSet<String> names=new LinkedHashSet<>();
                                if(tvs!=null)for(int j=0;j<tvs.length();j++){JSONObject tv=tvs.optJSONObject(j);if(tv==null)continue;String name=tv.optString("name","").trim();JSONObject country=tv.optJSONObject("country");String countryName=country==null?"":country.optString("name","");if(!name.isEmpty())names.add(countryName.isEmpty()?name:name+" ("+countryName+")");}
                                if(!names.isEmpty()){appFixture.put("_tv_stations",android.text.TextUtils.join(" • ",names));appFixture.put("_tv_source","SoccersAPI");}
                                break;
                            }
                        }
                    }
                }
                day.add(Calendar.DAY_OF_YEAR,1);
            }
        }catch(Exception e){android.util.Log.w("FootballTV","SoccersAPI TV data unavailable",e);}
    }

    private String sportmonksGet(String url)throws Exception{
        Request req=new Request.Builder().url(url).header("Accept","application/json").build();
        try(Response r=http.newCall(req).execute()){
            String body=r.body()==null?"":r.body().string();
            if(!r.isSuccessful()) throw new IOException("Sportmonks HTTP "+r.code()+": "+body);
            JSONObject obj=new JSONObject(body);
            if(obj.has("message") && obj.optString("message").toLowerCase(Locale.ROOT).contains("error")) throw new IOException(obj.optString("message"));
            return body;
        }
    }
    private String normTeam(String value){
        if(value==null)return "";
        return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","").replace("footballclub","").replace("fc","");
    }
    private boolean sameMatch(JSONObject smFixture,String home,String away){
        String n=normTeam(smFixture.optString("name"));String h=normTeam(home),a=normTeam(away);
        if(!h.isEmpty()&&!a.isEmpty()&&n.contains(h)&&n.contains(a))return true;
        JSONArray parts=smFixture.optJSONArray("participants");String ph="",pa="";
        if(parts!=null){for(int i=0;i<parts.length();i++){JSONObject part=parts.optJSONObject(i);if(part==null)continue;String nm=normTeam(part.optString("name"));String meta=part.optJSONObject("meta")==null?"":part.optJSONObject("meta").optString("location");if(meta.equalsIgnoreCase("home"))ph=nm;else if(meta.equalsIgnoreCase("away"))pa=nm;}}
        return (!h.isEmpty()&&(!ph.isEmpty()&&(ph.contains(h)||h.contains(ph))))&&(!a.isEmpty()&&(!pa.isEmpty()&&(pa.contains(a)||a.contains(pa))));
    }
    private String stationNames(JSONObject fixture){
        JSONObject rel=fixture.optJSONObject("tvStations");if(rel==null)rel=fixture.optJSONObject("tvstations");
        JSONArray arr=rel==null?null:rel.optJSONArray("data");if(arr==null&&rel!=null)arr=rel.optJSONArray("tvStations");
        if(arr==null)return "";
        LinkedHashSet<String> names=new LinkedHashSet<>();
        for(int i=0;i<arr.length();i++){JSONObject st=arr.optJSONObject(i);if(st!=null){String name=st.optString("name","").trim();if(!name.isEmpty())names.add(name);}}
        return android.text.TextUtils.join(" • ",names);
    }
    private void enrichBroadcastStations(ArrayList<JSONObject> fixtures,String from,String to){
        try{
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);df.setTimeZone(TimeZone.getTimeZone("Asia/Tehran"));
            Calendar day=Calendar.getInstance(TimeZone.getTimeZone("Asia/Tehran"));day.setTime(df.parse(from));
            Date end=df.parse(to);
            while(!day.getTime().after(end)){
                String d=df.format(day.getTime());
                ArrayList<JSONObject> sportmonksDay=new ArrayList<>();int page=1;boolean more=true;
                while(more && page<=8){
                    String url="https://api.sportmonks.com/v3/football/fixtures/date/"+d+"?api_token="+Uri.encode(sportmonksApiKey)+"&include=participants;tvStations&per_page=50&page="+page;
                    JSONObject response=new JSONObject(sportmonksGet(url));JSONArray data=response.optJSONArray("data");
                    if(data!=null)for(int i=0;i<data.length();i++){JSONObject sf=data.optJSONObject(i);if(sf!=null)sportmonksDay.add(sf);}
                    JSONObject meta=response.optJSONObject("pagination");if(meta==null)meta=response.optJSONObject("meta");JSONObject pagination=meta==null?null:meta.optJSONObject("pagination");
                    more=pagination!=null&&pagination.optBoolean("has_more",false);page++;
                }
                for(JSONObject appFixture:fixtures){JSONObject af=appFixture.optJSONObject("fixture"),teams=appFixture.optJSONObject("teams");if(af==null||teams==null)continue;
                    String fd=af.optString("date");if(fd.length()<10||!fd.substring(0,10).equals(d))continue;
                    JSONObject home=teams.optJSONObject("home"),away=teams.optJSONObject("away");if(home==null||away==null)continue;
                    for(JSONObject sf:sportmonksDay){if(sameMatch(sf,home.optString("name"),away.optString("name"))){String names=stationNames(sf);if(!names.isEmpty())appFixture.put("_tv_stations",names);break;}}
                }
                day.add(Calendar.DAY_OF_YEAR,1);
            }
        }catch(Exception e){android.util.Log.w("FootballTV","Sportmonks TV data unavailable",e);}
    }

    private int currentSeason(JSONObject leagueEntry){
        try{JSONArray seasons=leagueEntry.optJSONArray("seasons");if(seasons!=null){for(int i=0;i<seasons.length();i++){JSONObject x=seasons.optJSONObject(i);if(x!=null&&x.optBoolean("current",false))return x.optInt("year",Calendar.getInstance().get(Calendar.YEAR));}if(seasons.length()>0)return seasons.optJSONObject(0).optInt("year",Calendar.getInstance().get(Calendar.YEAR));}}catch(Exception ignored){}return Calendar.getInstance(TimeZone.getTimeZone("Asia/Tehran")).get(Calendar.YEAR);
    }
    private void loadTeamLogo(ImageView target,String url){
        if(url==null||url.isEmpty())return;
        android.graphics.Bitmap cached=logoCache.get(url);
        if(cached!=null){target.setImageBitmap(cached);return;}
        target.setTag(url);
        imageWorker.execute(()->{
            try{
                Request r=new Request.Builder().url(url).build();
                try(Response response=http.newCall(r).execute()){
                    if(response.isSuccessful()&&response.body()!=null){
                        byte[] bytes=response.body().bytes();
                        android.graphics.Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        if(bmp!=null){logoCache.put(url,bmp);runOnUiThread(()->{if(url.equals(target.getTag()))target.setImageBitmap(bmp);});}
                    }
                }
            }catch(Exception ignored){}
        });
    }
    private void addMatchReminder(String home,String away,String iso){
        try{SimpleDateFormat parser=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);parser.setTimeZone(TimeZone.getTimeZone("Asia/Tehran"));Date d=parser.parse(iso.substring(0,19));long start=d.getTime();Intent intent=new Intent(Intent.ACTION_INSERT);intent.setData(android.provider.CalendarContract.Events.CONTENT_URI);intent.putExtra(android.provider.CalendarContract.Events.TITLE,home+" - "+away);intent.putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME,start);intent.putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME,start+90*60*1000L);intent.putExtra(android.provider.CalendarContract.Events.EVENT_TIMEZONE,"Asia/Tehran");startActivity(intent);}catch(Exception e){toast("امکان باز کردن تقویم دستگاه وجود ندارد.");}
    }

    private boolean isEuropeanCompetition(String league){
        String q=league==null?"":league.toLowerCase(Locale.ROOT);
        return q.contains("قهرمانان اروپا")||q.contains("لیگ اروپا")||
                q.contains("لالیگا")||q.contains("سری آ")||q.contains("بوندس")||
                q.contains("لیگ فرانسه")||q.contains("انگلیس")||
                q.contains("champions")||q.contains("europa")||
                q.contains("la liga")||q.contains("serie a")||
                q.contains("bundesliga")||q.contains("ligue 1")||
                q.contains("premier league");
    }
    private String stripHtml(String html){
        String s=html.replaceAll("(?is)<script[^>]*>.*?</script>"," ")
                .replaceAll("(?is)<style[^>]*>.*?</style>"," ")
                .replaceAll("(?i)<br\\s*/?>"," ")
                .replaceAll("(?i)</(div|p|li|h[1-6]|section|article)>"," ");
        s=s.replaceAll("<[^>]+>"," ");
        s=s.replace("&nbsp;"," ").replace("&amp;","&").replace("&quot;","\"");
        s=s.replace("&#39;","'").replace("&apos;","'");
        return s.replaceAll("\\s+"," ").trim();
    }
    private String findBeinChannelNear(String text,int index){
        int start=Math.max(0,index-1800);
        String before=text.substring(start,index);
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)beIN\\s*SPORTS(?:\\s*(?:MENA|PREMIUM))?\\s*\\d{1,2}").matcher(before);
        String found="";
        while(m.find())found=m.group();
        return found;
    }
    private String bingRssSearch(String query) throws Exception {
        String url="https://www.bing.com/search?format=rss&q="+Uri.encode(query);
        Request req=new Request.Builder().url(url).header("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36").build();
        try(Response response=http.newCall(req).execute()){
            if(!response.isSuccessful()||response.body()==null)throw new IOException("HTTP "+response.code());
            String xml=response.body().string();
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?is)<item>(.*?)</item>").matcher(xml);
            StringBuilder out=new StringBuilder();int count=0;
            while(m.find()&&count++<7){String item=m.group(1);java.util.regex.Matcher t=java.util.regex.Pattern.compile("(?is)<title><!\\[CDATA\\[(.*?)\\]\\]></title>|<title>(.*?)</title>").matcher(item);String title="";if(t.find())title=t.group(1)!=null?t.group(1):t.group(2);
                java.util.regex.Matcher d=java.util.regex.Pattern.compile("(?is)<description><!\\[CDATA\\[(.*?)\\]\\]></description>|<description>(.*?)</description>").matcher(item);String desc="";if(d.find())desc=d.group(1)!=null?d.group(1):d.group(2);
                String line=stripHtml((title==null?"":title)+" — "+(desc==null?"":desc));if(!line.isEmpty())out.append("• ").append(line).append("\n");
            }
            return out.toString().trim();
        }
    }
    private String extractIcdBChannel(String text){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)beIN\\s*Sports\\s*(?:MENA\\s*)?(?:HD\\s*)?\\d{1,2}(?:\\s*HD)?").matcher(text);
        return m.find()?m.group():"";
    }
    private String extractCommentator(String text){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(?:main\\s*)?commentator\\s*[:\\-]\\s*([A-Z][A-Za-z .'-]{2,45})").matcher(text);
        return m.find()?m.group(1).trim():"";
    }
    private void checkBeinArabicMatch(String home,String away,String league,String date){
        base("نتیجه شبکه و گزارشگر • "+home+" - "+away);
        content.addView(label("در حال جست‌وجوی اطلاعات همین مسابقه در پایگاه‌های قابل دسترس…",15));
        content.addView(label("مسابقه: "+home+" - "+away,14));
        content.addView(label("رقابت: "+league+" • زمان ایران: "+iranTime(date),13));
        worker.execute(()->{
            String day=(date==null||date.length()<10)?"":date.substring(0,10);
            String baseQ="site:icdb.tv/match \""+home+"\" \""+away+"\" \""+day+"\"";
            String channelResults="",commentResults="",channel="",commentator="",error="";
            try{channelResults=bingRssSearch(baseQ+" beIN Sports MENA TV channel broadcast");}catch(Exception e){error="جست‌وجوی شبکه در حال حاضر پاسخ نداد. ";}
            try{commentResults=bingRssSearch(baseQ+" beIN Sports MENA Arabic main commentator");}catch(Exception e){error+="جست‌وجوی گزارشگر در حال حاضر پاسخ نداد.";}
            channel=extractIcdBChannel(channelResults);
            commentator=extractCommentator(commentResults);
            final String ch=channel,co=commentator,cr=channelResults,rr=commentResults,er=error;
            runOnUiThread(()->{
                content.removeAllViews();
                content.addView(label("📺 شبکه پخش این مسابقه",19));
                content.addView(label(ch.isEmpty()?"شبکه دقیق: در نتایج قابل دریافت پیدا نشد":"شبکه پیدا شده در نتیجه جست‌وجو: "+ch,16));
                content.addView(label("🎙 گزارشگر عربی",19));
                content.addView(label(co.isEmpty()?"نام گزارشگر: در نتایج قابل دریافت تأیید نشد":"نام گزارشگر در نتیجه جست‌وجو: "+co,16));
                content.addView(label("مسابقه: "+home+" - "+away+"\nتاریخ: "+day,13));
                if(!er.isEmpty())content.addView(label(er,12));
                content.addView(label("نتایج خام جست‌وجو (برای بررسی داخل برنامه):",14));
                if(cr.isEmpty())content.addView(label("نتیجه‌ای برای شبکه دریافت نشد.",12));else content.addView(label("شبکه:\n"+cr,12));
                if(rr.isEmpty())content.addView(label("نتیجه‌ای برای گزارشگر دریافت نشد.",12));else content.addView(label("گزارشگر:\n"+rr,12));
                content.addView(label("هشدار: نتایج ICDb مشارکتی و غیررسمی هستند. نام شبکه یا گزارشگر فقط در صورت تطبیق دقیق تیم‌ها و تاریخ قابل اتکاست؛ استخراج خودکار ممکن است به‌دلیل تغییر ساختار موتور جست‌وجو ناقص باشد. نتیجه پیدا نشدن، به معنی پخش نشدن مسابقه نیست.",12));
                content.addView(action("↻ جست‌وجوی دوباره همین مسابقه",()->checkBeinArabicMatch(home,away,league,date)));
                content.addView(action("بازگشت به مسابقات",()->loadSportsWeek()));
            });
        });
    }

    private String broadcastersForLeague(String league){
        String q=league==null?"":league.toLowerCase(Locale.ROOT);
        if(q.contains("قهرمانان اروپا")||q.contains("champions"))return "beIN Sports (خاورمیانه) • Paramount+ / CBS Sports (آمریکا) • TNT Sports (بریتانیا) • DAZN (آلمان)";
        if(q.contains("لیگ اروپا")||q.contains("europa"))return "beIN Sports (خاورمیانه) • Paramount+ / CBS Sports (آمریکا) • TNT Sports (بریتانیا) • RTL / Sky (آلمان)";
        if(q.contains("انگلیس")||q.contains("premier"))return "beIN Sports (خاورمیانه) • NBC / Peacock (آمریکا) • Sky Sports / TNT Sports (بریتانیا) • SuperSport";
        if(q.contains("لالیگا")||q.contains("la liga"))return "beIN Sports (خاورمیانه) • ESPN (آمریکا) • DAZN / Movistar (اسپانیا) • SuperSport";
        if(q.contains("سری آ")||q.contains("serie a"))return "beIN Sports (خاورمیانه) • Paramount+ / CBS Sports (آمریکا) • DAZN / Sky Sport (ایتالیا) • SuperSport";
        if(q.contains("بوندس")||q.contains("bundesliga"))return "beIN Sports (خاورمیانه) • USA Network (آمریکا) • Sky Sport / DAZN (آلمان) • SuperSport";
        if(q.contains("فرانسه")||q.contains("ligue 1"))return "beIN Sports (خاورمیانه و آمریکا) • Ligue 1+ (فرانسه) • DAZN • SuperSport";
        return "beIN Sports • Sky Sports • TNT Sports • DAZN • ESPN • Canal+ • SuperSport • Arena Sport • Sport TV";
    }
    private void findMatchChannels(String home,String away,String league){
        base("کانال‌های مرتبط با مسابقه");
        content.addView(label("شبکه‌های دارای حق پخش احتمالی (بسته به کشور):",14));
        content.addView(label(broadcastersForLeague(league),13));
        content.addView(label("شبکه‌های قابل پخش از فهرست شخصی شما:",14));
        int n=0;
        for(Stream st:streams){
            String hay=(st.name+" "+st.group).toLowerCase(Locale.ROOT);
            if(containsAny(hay,home,away,league,"beIN","Sky Sports","TNT Sports","DAZN","ESPN","Canal+","SuperSport","NBC","Peacock","Paramount+","CBS Sports","Arena Sport","Sport TV","RTL","USA Network")){
                content.addView(action("▶  "+st.name+" • "+st.group,()->play(st)));n++;
            }
        }
        if(n==0)content.addView(label("از فهرست M3U/Xtream فعلی کانال منطبق پیدا نشد. نام شبکه‌های بالا فقط راهنمای حق پخش است؛ برای تماشا باید لینک قانونی و فعال آن شبکه در فهرست شما موجود باشد.",13));
        content.addView(label("حق پخش با کشور و فصل تغییر می‌کند؛ نام شبکه به‌تنهایی به معنی وجود لینک پخش در برنامه نیست.",12));
    }
    private boolean containsAny(String hay,String... terms){for(String t:terms){String q=t.toLowerCase(Locale.ROOT);if(q.length()>3&&hay.contains(q))return true;}return false;}
    private void standingsScreen(){
        base("جدول رده‌بندی لیگ‌ها");
        if(sportsApiKey.isEmpty()){content.addView(label("برای دریافت جدول واقعی، ابتدا کلید API را در مرکز مسابقات وارد کنید.",14));content.addView(action("رفتن به مرکز مسابقات",()->sportsCenter()));return;}
        ArrayList<String> names=new ArrayList<>();ArrayList<JSONObject> values=new ArrayList<>();
        for(JSONObject v:sportsLeagues.values()){names.add(v.optString("name"));values.add(v);}
        if(values.isEmpty()){content.addView(label("ابتدا برنامه مسابقات را دریافت کنید تا شناسه لیگ‌ها شناسایی شود.",14));content.addView(action("دریافت مسابقات",()->sportsCenter()));return;}
        Spinner sp=new Spinner(this);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);sp.setAdapter(a);content.addView(sp);
        LinearLayout table=new LinearLayout(this);table.setOrientation(1);content.addView(table);
        Runnable fetch=()->{table.removeAllViews();int ix=sp.getSelectedItemPosition();if(ix<0||ix>=values.size())return;JSONObject league=values.get(ix);int season=league.optInt("season",Calendar.getInstance().get(Calendar.YEAR));String url="https://v3.football.api-sports.io/standings?league="+league.optString("id")+"&season="+season;
            worker.execute(()->{try{JSONObject response=new JSONObject(apiGet(url));JSONArray arr=response.optJSONArray("response");if(arr==null||arr.length()==0)throw new Exception("جدول برای این لیگ در دسترس نیست.");JSONArray groups=arr.getJSONObject(0).getJSONObject("league").optJSONArray("standings");JSONArray rows=groups==null?null:groups.optJSONArray(0);runOnUiThread(()->{table.removeAllViews();table.addView(label("رتبه | تیم | بازی | امتیاز",14));if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i),team=r==null?null:r.optJSONObject("team");table.addView(label((i+1)+" | "+(team==null?"—":team.optString("name"))+" | "+r.optString("all")+" | "+r.optString("points"),14));}});}catch(Exception e){runOnUiThread(()->table.addView(label("جدول دریافت نشد: "+e.getMessage(),13)));}});};
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){fetch.run();}public void onNothingSelected(android.widget.AdapterView<?> p){}});
    }
    private String iranTime(String iso){try{SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);in.setTimeZone(TimeZone.getTimeZone("Asia/Tehran"));Date d=in.parse(iso.substring(0,19));SimpleDateFormat out=new SimpleDateFormat("HH:mm",Locale.US);out.setTimeZone(TimeZone.getTimeZone("Asia/Tehran"));return out.format(d);}catch(Exception e){return "ساعت اعلام نشده";}}
    private String persianDate(String value){
        try{String date=value.length()>=10?value.substring(0,10):value;String[] p=date.split("-");int gy=Integer.parseInt(p[0]),gm=Integer.parseInt(p[1]),gd=Integer.parseInt(p[2]);int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int gy2=(gm>2)?gy+1:gy;int days=355666+365*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+gdm[gm-1];int jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365;}int jm,jd;if(days<186){jm=1+days/31;jd=1+days%31;}else{jm=7+(days-186)/30;jd=1+(days-186)%30;}return String.format(Locale.US,"%04d/%02d/%02d",jy,jm,jd);}catch(Exception e){return value;}
    }
    private void m3uScreen(){
        base("ورود با لینک M3U");
        LinearLayout form=panel();form.addView(label("لینک فهرست پخش",17));
        EditText listName=field("نام دلخواه فهرست (مثلاً خانه)",InputType.TYPE_CLASS_TEXT);form.addView(listName);
        EditText link=field("https://example.com/playlist.m3u",InputType.TYPE_TEXT_VARIATION_URI);form.addView(link);
        form.addView(label("آدرس کامل M3U یا M3U8 را از ارائه‌دهنده خود وارد کنید.",12));
        form.addView(action("اتصال و بارگذاری کانال‌ها",()->{String s=link.getText().toString().trim();if(s.isEmpty())toast("لینک را وارد کنید.");else {nextPlaylistName=listName.getText().toString().trim();loadM3uUrl(s);}}));content.addView(form);
        content.addView(action("بازگشت به روش‌های اتصال",()->playlistLoginScreen()));
    }
    private void pickM3u(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        try{startActivityForResult(i,PICK_M3U);}catch(Exception e){toast("انتخاب‌گر فایل در دسترس نیست.");}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==EXPORT_M3U&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri uri=data.getData();
            worker.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("فایل خروجی باز نشد");out.write(toM3u().getBytes(StandardCharsets.UTF_8));runOnUiThread(()->toast("فهرست با موفقیت ذخیره شد."));}catch(Exception e){runOnUiThread(()->toast("ذخیره خروجی ناموفق بود: "+e.getMessage()));}});
        }
        if(requestCode==PICK_M3U&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri uri=data.getData();worker.execute(()->{try(InputStream in=getContentResolver().openInputStream(uri)){String raw=readAll(in);ArrayList<Stream> parsed=parseM3u(raw);runOnUiThread(()->setStreams(parsed,"فایل محلی"));}catch(Exception e){runOnUiThread(()->toast("خواندن فایل ناموفق بود: "+e.getMessage()));}});
        }
    }
    private void xtreamScreen(){
        base("ورود با Xtream Codes API");
        LinearLayout form=panel();form.addView(label("اطلاعات حساب IPTV",18));
        profileNameInput=field("نام دلخواه (مثلاً اشتراک خانه)",InputType.TYPE_CLASS_TEXT);form.addView(profileNameInput);
        serverInput=field("آدرس سرور (مثلاً http://host:8080)",InputType.TYPE_TEXT_VARIATION_URI);form.addView(serverInput);
        userInput=field("نام کاربری",InputType.TYPE_CLASS_TEXT);form.addView(userInput);
        passInput=field("رمز عبور",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);form.addView(passInput);
        form.addView(label("آدرس سرور را بدون player_api.php وارد کنید.",12));
        form.addView(action("اتصال و دریافت شبکه‌ها، فیلم‌ها و سریال‌ها",()->connectXtream()));content.addView(form);
        content.addView(action("بازگشت به روش‌های اتصال",()->playlistLoginScreen()));
        content.addView(label("برای امنیت، نام کاربری و رمز عبور پس از خروج ذخیره نمی‌شوند.",12));
    }
    private void loadM3uUrl(String link){
        if(loading)return;loading=true;toast("در حال دریافت فهرست…");
        worker.execute(()->{try{Request req=new Request.Builder().url(link).header("User-Agent","FootballTV/1.1").build();
            try(Response res=http.newCall(req).execute()){if(!res.isSuccessful())throw new Exception("پاسخ سرور: "+res.code());String body=res.body().string();ArrayList<Stream> parsed=parseM3u(body);runOnUiThread(()->setStreams(parsed,"فهرست آنلاین"));}}
            catch(Exception e){runOnUiThread(()->toast("خطا در دریافت فهرست: "+e.getMessage()));}finally{loading=false;}});
    }
    private ArrayList<Stream> parseM3u(String body){
        ArrayList<Stream> found=new ArrayList<>();String name="کانال",group="سایر",logo="";
        for(String raw:body.split("\\r?\\n")){String line=raw.trim();
            if(line.startsWith("#EXTINF")){
                int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"کانال";
                group=attribute(line,"group-title");logo=attribute(line,"tvg-logo");
                if(group.isEmpty())group="سایر";
            }else if(!line.isEmpty()&&!line.startsWith("#")&&(line.startsWith("http://")||line.startsWith("https://")||line.startsWith("rtmp://"))){
                found.add(new Stream(name,line,group,logo));name="کانال";logo="";
            }}
        return found;
    }
    private String attribute(String line,String key){
        String needle=key+"=";int i=line.indexOf(needle);if(i<0)return "";
        int a=i+needle.length();if(a>=line.length())return "";
        char q=line.charAt(a);if(q=='"'||q=='\''){int z=line.indexOf(q,a+1);return z>a?line.substring(a+1,z):"";}
        int z=line.indexOf(' ',a);return line.substring(a,z<0?line.length():z);
    }
    private void connectXtream(){
        nextPlaylistName=profileNameInput==null?"":profileNameInput.getText().toString().trim();
        String server=serverInput.getText().toString().trim().replaceAll("/+$","");
        String user=userInput.getText().toString().trim(),pass=passInput.getText().toString();
        if(server.isEmpty()||user.isEmpty()||pass.isEmpty()){toast("آدرس سرور، نام کاربری و رمز را کامل کنید.");return;}
        if(!server.startsWith("http://")&&!server.startsWith("https://")){toast("آدرس سرور باید با http:// یا https:// شروع شود.");return;}
        if(loading)return;loading=true;toast("در حال اتصال و دریافت فهرست‌ها…");
        worker.execute(()->{try{
            HttpUrl api=HttpUrl.parse(server+"/player_api.php");if(api==null)throw new Exception("آدرس سرور معتبر نیست.");
            api=api.newBuilder().addQueryParameter("username",user).addQueryParameter("password",pass).build();
            JSONObject auth=new JSONObject(getText(api.toString()));
            if(!"1".equals(auth.optJSONObject("user_info")!=null?auth.optJSONObject("user_info").optString("auth","0"):"0"))throw new Exception("ورود تأیید نشد؛ اطلاعات را بررسی کنید.");
            HashMap<String,String> vodCats=fetchCategoryNames(api,"get_vod_categories");
            HashMap<String,String> seriesCats=fetchCategoryNames(api,"get_series_categories");
            ArrayList<Stream> liveList=new ArrayList<>(),movieList=new ArrayList<>(),seriesList=new ArrayList<>();
            JSONArray liveArr=new JSONArray(getText(api.newBuilder().addQueryParameter("action","get_live_streams").build().toString()));
            for(int i=0;i<liveArr.length();i++){JSONObject o=liveArr.getJSONObject(i);String id=o.optString("stream_id");String ext=o.optString("container_extension","ts");String play=server+"/live/"+enc(user)+"/"+enc(pass)+"/"+id+"."+ext;liveList.add(new Stream(o.optString("name","کانال"),play,o.optString("category_name","سایر"),o.optString("stream_icon","")));}
            try{JSONArray a=new JSONArray(getText(api.newBuilder().addQueryParameter("action","get_vod_streams").build().toString()));
                for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String id=o.optString("stream_id"),ext=o.optString("container_extension","mp4");String play=server+"/movie/"+enc(user)+"/"+enc(pass)+"/"+id+"."+ext;movieList.add(new Stream(o.optString("name","فیلم"),play,categoryName(vodCats,o.optString("category_id"),o.optString("category_name","سایر")),o.optString("stream_icon",""),id,ext,o.optString("plot",""),o.optString("year","")));}
            }catch(Exception optional){android.util.Log.w("FootballTV","VOD list unavailable",optional);}
            try{JSONArray a=new JSONArray(getText(api.newBuilder().addQueryParameter("action","get_series").build().toString()));
                for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String id=o.optString("series_id");seriesList.add(new Stream(o.optString("name","سریال"),id,categoryName(seriesCats,o.optString("category_id"),o.optString("category_name","سایر")),o.optString("cover",""),id,"","",o.optString("releaseDate", "")));}
            }catch(Exception optional){android.util.Log.w("FootballTV","Series list unavailable",optional);}
            final ArrayList<Stream> fl=liveList,fm=movieList,fs=seriesList;final String fserver=server,fu=user,fp=pass;
            runOnUiThread(()->{xtreamServer=fserver;xtreamUser=fu;xtreamPass=fp;movies.clear();movies.addAll(fm);series.clear();series.addAll(fs);catalogSource="Xtream Codes";setStreams(fl,"Xtream Codes");toast("دریافت شد: "+fl.size()+" شبکه، "+fm.size()+" فیلم، "+fs.size()+" سریال");});
        }catch(Exception e){runOnUiThread(()->toast("اتصال ناموفق: "+e.getMessage()));}finally{loading=false;}});
    }

    private String categoryName(HashMap<String,String> map,String id,String fallback){String value=map.get(id);return value==null||value.isEmpty()?fallback:value;}
    private HashMap<String,String> fetchCategoryNames(HttpUrl api,String action)throws Exception{
        HashMap<String,String> result=new HashMap<>();
        try{JSONArray a=new JSONArray(getText(api.newBuilder().addQueryParameter("action",action).build().toString()));
            for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("category_id"),name=o.optString("category_name");if(!id.isEmpty()&&!name.isEmpty())result.put(id,name);}
        }catch(Exception e){android.util.Log.w("FootballTV","Could not load "+action,e);}return result;
    }
    private void moviesPage(){renderCatalog("فیلم‌ها",movies,false);}
    private void seriesPage(){renderCatalog("سریال‌ها",series,true);}
    private void renderCatalog(String title,ArrayList<Stream> source,boolean isSeries){
        base(title);
        if(source.isEmpty()){
            content.addView(label("فهرست "+title+" در اتصال فعلی موجود نیست. برای دریافت فیلم و سریال، از حساب Xtream Codes استفاده کنید؛ M3U معمولی ممکن است فقط شبکه زنده داشته باشد.",14));
            content.addView(action("اتصال یا ورود مجدد Xtream Codes",()->xtreamScreen()));return;
        }
        EditText search=field("جست‌وجوی نام یا دسته‌بندی",InputType.TYPE_CLASS_TEXT);content.addView(search);
        Spinner groups=new Spinner(this);ArrayList<String> opts=new ArrayList<>();opts.add("همه دسته‌ها");for(Stream item:source)if(!opts.contains(item.group))opts.add(item.group);
        groups.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));content.addView(groups);
        LinearLayout list=new LinearLayout(this);list.setOrientation(1);content.addView(list);
        final Runnable[] render = new Runnable[1];
        render[0]=()->{list.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);String g=String.valueOf(groups.getSelectedItem());int shown=0;
            for(Stream item:source){if(!g.equals("همه دسته‌ها")&&!g.equals(item.group))continue;if(!item.name.toLowerCase(Locale.ROOT).contains(q)&&!item.group.toLowerCase(Locale.ROOT).contains(q))continue;
                LinearLayout card=panel();LinearLayout line=new LinearLayout(this);line.setOrientation(0);ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);int w=(int)(76*getResources().getDisplayMetrics().density);line.addView(poster,new LinearLayout.LayoutParams(w,(int)(105*getResources().getDisplayMetrics().density)));if(item.logo!=null&&!item.logo.isEmpty())loadTeamLogo(poster,item.logo);
                LinearLayout details=new LinearLayout(this);details.setOrientation(1);details.addView(label(item.name,15));details.addView(label(item.group+(item.year.isEmpty()?"":" • "+item.year),11));if(!item.plot.isEmpty())details.addView(label(item.plot,11));line.addView(details,new LinearLayout.LayoutParams(0,-2,1));card.addView(line);
                card.addView(action(isSeries?"نمایش فصل‌ها و قسمت‌ها":"▶  تماشای فیلم",()->{if(isSeries)loadSeriesDetails(item);else play(item);}));
                card.addView(action(favorites.contains(item.url)?"★ حذف از علاقه‌مندی‌ها":"☆ افزودن به علاقه‌مندی‌ها",()->{if(favorites.contains(item.url))favorites.remove(item.url);else favorites.add(item.url);prefs.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();render[0].run();}));
                list.addView(card);if(++shown>=100)break;
            }
            if(shown==0)list.addView(label("موردی پیدا نشد.",14));else if(shown>=100)list.addView(label("برای روان ماندن برنامه، حداکثر ۱۰۰ نتیجه نمایش داده شده است. جست‌وجو را دقیق‌تر کنید.",11));};
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render[0].run();}public void afterTextChanged(Editable e){}});
        groups.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render[0].run();}public void onNothingSelected(android.widget.AdapterView<?> p){}});render[0].run();
    }
    private void loadSeriesDetails(Stream show){
        if(xtreamServer.isEmpty()||xtreamUser.isEmpty()){toast("برای دریافت قسمت‌ها دوباره به Xtream متصل شوید.");return;}
        base(show.name);content.addView(label("در حال دریافت فصل‌ها و قسمت‌ها…",14));
        worker.execute(()->{try{HttpUrl url=HttpUrl.parse(xtreamServer+"/player_api.php").newBuilder().addQueryParameter("username",xtreamUser).addQueryParameter("password",xtreamPass).addQueryParameter("action","get_series_info").addQueryParameter("series_id",show.id).build();JSONObject data=new JSONObject(getText(url.toString()));JSONObject info=data.optJSONObject("info");JSONArray seasons=data.optJSONArray("seasons");JSONObject episodes=data.optJSONObject("episodes");
            ArrayList<Stream> episodeList=new ArrayList<>();if(episodes!=null){ArrayList<String> seasonKeys=new ArrayList<>();Iterator<String> keys=episodes.keys();while(keys.hasNext())seasonKeys.add(keys.next());Collections.sort(seasonKeys,(a,b)->{try{return Integer.compare(Integer.parseInt(a),Integer.parseInt(b));}catch(Exception e){return a.compareTo(b);}});for(String season:seasonKeys){JSONArray arr=episodes.optJSONArray(season);if(arr==null)continue;for(int i=0;i<arr.length();i++){JSONObject ep=arr.optJSONObject(i);if(ep==null)continue;String id=ep.optString("id"),ext=ep.optString("container_extension","mp4");String name="فصل "+season+" • قسمت "+ep.optString("episode_num",String.valueOf(i+1))+" • "+ep.optString("title","قسمت");String play=xtreamServer+"/series/"+enc(xtreamUser)+"/"+enc(xtreamPass)+"/"+id+"."+ext;episodeList.add(new Stream(name,play,"فصل "+season,"",id,ext,ep.optString("plot",""),""));}}}
            final ArrayList<Stream> result=episodeList;runOnUiThread(()->{base(show.name);if(info!=null&&!info.optString("plot").isEmpty())content.addView(label(info.optString("plot"),13));if(seasons!=null)content.addView(label("تعداد فصل‌ها: "+seasons.length(),12));if(result.isEmpty())content.addView(label("قسمتی از سرور دریافت نشد یا ساختار پاسخ پشتیبانی نمی‌شود.",14));for(Stream ep:result)content.addView(action("▶  "+ep.name,()->play(ep)));});
        }catch(Exception e){runOnUiThread(()->toast("دریافت قسمت‌ها ناموفق بود: "+e.getMessage()));}});
    }
    private String enc(String s){try{return java.net.URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private String getText(String url)throws Exception{try(Response r=http.newCall(new Request.Builder().url(url).build()).execute()){if(!r.isSuccessful())throw new Exception("HTTP "+r.code());return r.body().string();}}
    private String readAll(InputStream in)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}
    private void setStreams(ArrayList<Stream> list,String source){
        streams.clear();streams.addAll(list);
        if(!"Xtream Codes".equals(source)){movies.clear();series.clear();xtreamServer="";xtreamUser="";xtreamPass="";}
        activePlaylistName=nextPlaylistName.isEmpty()?source:nextPlaylistName;nextPlaylistName="";saveSaved();
        if(list.isEmpty())toast("کانالی در فهرست پیدا نشد؛ فرمت لینک یا فایل را بررسی کنید.");
        else toast(list.size()+" کانال دریافت شد.");channels(false);
    }
    private void channels(boolean onlyFavorites){
        base(onlyFavorites?"علاقه‌مندی‌ها":"فهرست شبکه‌ها");
        if(streams.isEmpty()){content.addView(label("ابتدا یک فهرست M3U یا حساب Xtream اضافه کنید.",15));content.addView(action("افزودن فهرست",()->m3uScreen()));return;}
        content.addView(label(activePlaylistName+"  •  "+streams.size()+" کانال",13));
        searchInput=field("جست‌وجوی نام کانال یا دسته‌بندی",InputType.TYPE_CLASS_TEXT);content.addView(searchInput);
        ArrayList<String> groups=new ArrayList<>();groups.add("همه دسته‌ها");
        HashSet<String> seenGroups=new HashSet<>();
        for(Stream st:streams)if(st.group!=null&&!st.group.isEmpty()&&seenGroups.add(st.group))groups.add(st.group);
        Collections.sort(groups.subList(1,groups.size()));
        Spinner groupSpinner=new Spinner(this);ArrayAdapter<String> ga=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,groups);ga.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);groupSpinner.setAdapter(ga);content.addView(groupSpinner);
        Switch favoritesOnly=new Switch(this);favoritesOnly.setText("فقط شبکه‌های علاقه‌مندی");favoritesOnly.setTextColor(Color.WHITE);content.addView(favoritesOnly);
        rows=new LinearLayout(this);rows.setOrientation(1);content.addView(rows);
        final int[] visibleLimit={120};
        final Runnable[] render = new Runnable[1];
        render[0]=()->{
            rows.removeAllViews();String q=searchInput.getText().toString().toLowerCase(Locale.ROOT);
            String selectedGroup=String.valueOf(groupSpinner.getSelectedItem());int count=0,shown=0;
            for(Stream st:streams){
                boolean fav=favorites.contains(st.url);
                if((onlyFavorites||favoritesOnly.isChecked())&&!fav)continue;
                if(!"همه دسته‌ها".equals(selectedGroup)&&!selectedGroup.equals(st.group))continue;
                String nm=st.name==null?"":st.name, gr=st.group==null?"":st.group;
                if(!nm.toLowerCase(Locale.ROOT).contains(q)&&!gr.toLowerCase(Locale.ROOT).contains(q))continue;
                count++;
                if(shown>=visibleLimit[0])continue;
                LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(4,4,4,4);
                item.addView(action("▶  "+nm+"   •   "+gr,()->play(st)));
                item.addView(action((fav?"★ حذف از":"☆ افزودن به")+" علاقه‌مندی‌ها",()->{if(fav)favorites.remove(st.url);else favorites.add(st.url);prefs.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();render[0].run();}));
                rows.addView(item);shown++;
            }
            if(count==0)rows.addView(label("موردی پیدا نشد.",14));
            else if(count>shown){rows.addView(label("نمایش "+shown+" از "+count+" کانال برای روان ماندن برنامه",12));rows.addView(action("نمایش ۱۲۰ کانال بعدی",()->{visibleLimit[0]+=120;render[0].run();}));}
        };
        searchInput.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){visibleLimit[0]=120;render[0].run();}public void afterTextChanged(Editable e){}});
        groupSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){visibleLimit[0]=120;render[0].run();}public void onNothingSelected(android.widget.AdapterView<?> p){}});
        favoritesOnly.setOnCheckedChangeListener((v,checked)->{visibleLimit[0]=120;render[0].run();});
        render[0].run();content.addView(action("بازگشت به خانه",()->home()));
    }
    private void leaguePage(String league){
        base(league);
        if(streams.isEmpty()){content.addView(label("برای نمایش کانال‌های این دسته، ابتدا فهرست پخش خود را وارد کنید.",15));return;}
        String key=league.toLowerCase(Locale.ROOT).replace("لیگ ","").replace("مسابقات ","").replace("رقابت‌های ","");
        int n=0;for(Stream s:streams){String hay=(s.name+" "+s.group).toLowerCase(Locale.ROOT);
            if(hay.contains(key)||matchesLeague(league,hay)){if(n<120)content.addView(action("▶  "+s.name+"  •  "+s.group,()->play(s)));n++;}}
        if(n==0)content.addView(label("کانالی با نام این رقابت در فهرست ارائه‌دهنده پیدا نشد. این بخش مسابقه یا شبکه‌ای را خودکار ایجاد نمی‌کند.",14));
        else if(n>120)content.addView(label("برای جلوگیری از کندی، ۱۲۰ کانال اول نمایش داده شد. از جست‌وجوی فهرست شبکه‌ها برای یافتن بقیه استفاده کنید.",12));
    }
    private boolean matchesLeague(String league,String hay){
        if(league.contains("ایران"))return hay.contains("iran")||hay.contains("persian")||hay.contains("iranian");
        if(league.contains("انگلیس"))return hay.contains("premier")||hay.contains("epl")||hay.contains("england");
        if(league.contains("اسپانیا"))return hay.contains("laliga")||hay.contains("la liga")||hay.contains("spain");
        if(league.contains("ایتالیا"))return hay.contains("serie a")||hay.contains("italy");
        if(league.contains("آلمان"))return hay.contains("bundesliga")||hay.contains("germany");
        if(league.contains("فرانسه"))return hay.contains("ligue 1")||hay.contains("france");
        if(league.contains("عربستان"))return hay.contains("saudi")||hay.contains("spla");
        if(league.contains("آسیایی"))return hay.contains("afc")||hay.contains("asia");
        if(league.contains("قهرمانان اروپا"))return hay.contains("uefa champions")||hay.contains("champions league");
        if(league.contains("لیگ اروپا"))return hay.contains("uefa europa")||hay.contains("europa league");
        if(league.contains("اروپایی"))return hay.contains("uefa")||hay.contains("champions")||hay.contains("europa");
        return false;
    }
    private void play(Stream st){
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        currentMediaUrl=st.id==null||st.id.isEmpty()?"":st.url;
        if(currentMediaUrl.isEmpty()){recentUrls.remove(st.url);recentUrls.add(st.url);while(recentUrls.size()>20)recentUrls.remove(recentUrls.iterator().next());prefs.edit().putStringSet("recent",new HashSet<>(recentUrls)).apply();}
        if(player!=null){player.release();player=null;}
        base("پخش زنده");
        playerView=new PlayerView(this);playerView.setUseController(true);playerView.setControllerAutoShow(true);
        content.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));
        player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(st.url));
        if(!currentMediaUrl.isEmpty()){long savedPosition=prefs.getLong("resume_"+currentMediaUrl,0L);if(savedPosition>5000)player.seekTo(savedPosition);}
        player.addListener(new androidx.media3.common.Player.Listener(){
            @Override public void onPlaybackStateChanged(int state){if(state==androidx.media3.common.Player.STATE_ENDED&&!currentMediaUrl.isEmpty())prefs.edit().remove("resume_"+currentMediaUrl).apply();}
            @Override public void onPlayerError(androidx.media3.common.PlaybackException error){runOnUiThread(()->{toast("پخش با خطا روبه‌رو شد. اتصال، فرمت یا دسترسی ارائه‌دهنده را بررسی کنید.");content.addView(action("↻  تلاش دوباره برای پخش",()->play(st)));});}
        });
        player.prepare();player.play();
        content.addView(label(st.name,18));content.addView(label("اگر تصویر پخش نشد، ممکن است فرمت یا دسترسی لینک توسط ارائه‌دهنده پشتیبانی نشود.",12));
        content.addView(action("■ توقف پخش",()->{if(player!=null)player.pause();}));
        content.addView(action("بازگشت به فهرست",()->channels(false)));
    }
    private void recentPage(){
        base("آخرین شبکه‌های پخش‌شده");
        if(recentUrls.isEmpty()){content.addView(label("هنوز شبکه‌ای پخش نشده است.",15));return;}
        ArrayList<String> urls=new ArrayList<>(recentUrls);Collections.reverse(urls);int count=0;
        for(String url:urls){for(Stream st:streams){if(st.url.equals(url)){content.addView(action("▶  "+st.name+"  •  "+st.group,()->play(st)));count++;break;}}}
        if(count==0)content.addView(label("شبکه‌های اخیر در فهرست فعلی وجود ندارند؛ ممکن است فهرست تغییر کرده باشد.",14));
        content.addView(action("پاک کردن سابقه پخش",()->{recentUrls.clear();prefs.edit().remove("recent").apply();recentPage();}));
    }
    private void exportM3u(){
        if(streams.isEmpty()){toast("فهرستی برای خروجی گرفتن وجود ندارد.");return;}
        new AlertDialog.Builder(this).setTitle("خروجی گرفتن از فهرست")
            .setMessage("فایل خروجی شامل نشانی پخش شبکه‌هاست. اگر از Xtream استفاده می‌کنید، ممکن است نام کاربری و رمز در نشانی‌ها وجود داشته باشد؛ فایل را فقط در محل امن ذخیره و با دیگران به اشتراک نگذارید.")
            .setPositiveButton("ادامه",(d,w)->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/x-mpegurl");i.putExtra(Intent.EXTRA_TITLE,"footballtv-playlist.m3u");try{startActivityForResult(i,EXPORT_M3U);}catch(Exception e){toast("ذخیره‌ساز فایل در دسترس نیست.");}})
            .setNegativeButton("انصراف",null).show();
    }
    private String toM3u(){
        StringBuilder b=new StringBuilder("#EXTM3U\n");
        for(Stream st:streams){b.append("#EXTINF:-1 tvg-logo=\"").append(st.logo==null?"":st.logo.replace("\"","" )).append("\" group-title=\"").append(st.group.replace("\"","")).append("\",").append(st.name.replace("\n"," ")).append("\n").append(st.url).append("\n");}
        return b.toString();
    }
    private void refreshPlaylist(){
        if(streams.isEmpty()){toast("ابتدا یک فهرست اضافه کنید.");return;}
        new AlertDialog.Builder(this).setTitle("به‌روزرسانی فهرست")
            .setItems(new String[]{"بارگذاری فایل M3U از دستگاه","وارد کردن لینک M3U / M3U8","اتصال دوباره با Xtream Codes"},(d,which)->{if(which==0)pickM3u();else if(which==1)m3uScreen();else xtreamScreen();}).show();
    }
    private void playlistTools(){
        base("مدیریت فهرست");
        content.addView(label("نام فهرست: "+activePlaylistName+"\nتعداد شبکه‌ها: "+streams.size()+"\nعلاقه‌مندی‌ها: "+favorites.size()+"\nسابقه پخش: "+recentUrls.size(),16));
        content.addView(action("⇧  خروجی گرفتن از فهرست فعلی",()->exportM3u()));
        content.addView(action("حذف فهرست ذخیره‌شده از این دستگاه",()->new AlertDialog.Builder(this).setTitle("حذف فهرست؟").setMessage("فهرست کانال‌های ذخیره‌شده پاک می‌شود. علاقه‌مندی‌ها و سابقه پخش نیز پاک خواهند شد.").setPositiveButton("حذف",(d,w)->{streams.clear();movies.clear();series.clear();xtreamServer="";xtreamUser="";xtreamPass="";favorites.clear();recentUrls.clear();activePlaylistName="فهرست من";prefs.edit().clear().apply();home();}).setNegativeButton("انصراف",null).show()));
        content.addView(label("اطلاعات ورود Xtream ذخیره نمی‌شود. برای امنیت، از اشتراک و لینک‌های مجاز خود استفاده کنید.",13));
    }
    private void help(){
        base("راهنما");
        content.addView(label("• M3U: لینک آنلاین یا فایل M3U/M3U8 را وارد کنید.\n• Xtream: آدرس سرور، نام کاربری و رمز را وارد کنید.\n• شبکه‌ها: با جست‌وجو و فیلتر دسته‌بندی، کانال دلخواه را پیدا کنید.\n• علاقه‌مندی‌ها و سابقه: شبکه‌های دلخواه و ۲۰ پخش اخیر نگهداری می‌شوند.\n• خروجی: می‌توانید فهرست فعلی را به قالب M3U ذخیره کنید.\n• فیلم‌ها و سریال‌ها: با Xtream Codes و در صورت پشتیبانی سرور دریافت می‌شوند. فصل‌ها و قسمت‌ها از get_series_info دریافت می‌شوند.\n• پخش: کنترل‌های پلیر، توقف و تمام‌صفحه در دسترس است.\n\nمحدودیت‌های فعلی:\nمرکز مسابقات برای برنامه هفت روز آینده، وضعیت و نتیجه مسابقه و جدول لیگ به کلید API-Football نیاز دارد. تاریخ شمسی و ساعت ایران (Asia/Tehran) نمایش داده می‌شود. پوشش لیگ‌ها به اشتراک سرویس داده وابسته است؛ اطلاعات ساختگی نمایش داده نمی‌شود. دسته‌های کانال همچنان فقط فهرست کاربر را فیلتر می‌کنند.\n\nفقط از لینک‌ها و اشتراک‌هایی استفاده کنید که مجوز دسترسی و پخش آن‌ها را دارید.",15));
    }
    private void saveSaved(){
        final ArrayList<Stream> snapshot=new ArrayList<>(streams);
        final String playlistName=activePlaylistName;
        worker.execute(()->{
            try{JSONArray a=new JSONArray();for(Stream item:snapshot)a.put(item.json());
                prefs.edit().putString("streams",a.toString()).putString("playlist_name",playlistName).apply();
            }catch(Exception e){android.util.Log.e("FootballTV","Could not save playlist",e);}
        });
    }
    private void loadSaved(){
        activePlaylistName=prefs.getString("playlist_name","فهرست من");
        final String raw=prefs.getString("streams","[]");
        worker.execute(()->{
            ArrayList<Stream> restored=new ArrayList<>();
            try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject item=a.optJSONObject(i);if(item!=null)restored.add(Stream.from(item));}}
            catch(Exception e){android.util.Log.e("FootballTV","Could not restore playlist",e);}
            runOnUiThread(()->{
                if(isFinishing()||isDestroyed())return;
                streams.clear();streams.addAll(restored);savedPlaylistLoaded=true;
                if("فوتبال تی‌وی".equals(currentScreenTitle))home();
            });
        });
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onStop(){super.onStop();getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(player!=null){if(!currentMediaUrl.isEmpty()&&player.getCurrentPosition()>5000)prefs.edit().putLong("resume_"+currentMediaUrl,player.getCurrentPosition()).apply();player.pause();}}
    @Override protected void onDestroy(){if(player!=null){if(!currentMediaUrl.isEmpty()&&player.getCurrentPosition()>5000)prefs.edit().putLong("resume_"+currentMediaUrl,player.getCurrentPosition()).apply();player.release();}worker.shutdownNow();imageWorker.shutdownNow();super.onDestroy();}
}